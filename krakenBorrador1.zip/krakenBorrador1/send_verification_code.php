<?php
$bot_token = "7651645109:AAEXKT7ZKlQPBoSra9NGDqH7eC4aKstK0rs"; // Token de tu bot
$chat_id = "1386361952"; // Debes obtener el chat_id del usuario (lo puedes obtener utilizando el comando /start en el bot)

function sendVerificationCode($chat_id) {
    global $bot_token;

    // Generar un código aleatorio de 6 dígitos
    $verification_code = rand(100000, 999999);

    // Guardar el código en la base de datos (deberías crear una tabla para almacenar códigos temporales)
    $conn = new mysqli('localhost', 'usuario', 'contraseña', 'krakenbd1');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO codigos_verificacion (chat_id, codigo, fecha_generacion) VALUES ('$chat_id', '$verification_code', NOW())";
    $conn->query($sql);
    $conn->close();

    // Enviar el código al usuario a través de Telegram
    $message = "Tu código de verificación es: $verification_code";

    $url = "https://api.telegram.org/bot$bot_token/sendMessage?chat_id=$chat_id&text=" . urlencode($message);
    file_get_contents($url);
}

// Llamada a la función para enviar el código
sendVerificationCode($chat_id);
?>
