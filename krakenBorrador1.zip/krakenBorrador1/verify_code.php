<?php
session_start();

// Verificar si el usuario está autenticado y tiene datos de sesión
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header('Location: login.php');
    exit();
}

// Datos del bot de Telegram
$bot_token = "7651645109:AAEXKT7ZKlQPBoSra9NGDqH7eC4aKstK0rs";
$chat_id = "1386361952";

// Variable para los mensajes
$message_sent = false;
$error_message = "";

// Si se presiona el botón para enviar el código
if (isset($_POST['send_code'])) {
    // Generar un nuevo código de verificación
    $_SESSION['verification_code'] = rand(100000, 999999);

    // Mensaje a enviar
    $message = "Tu nuevo código de verificación es: " . $_SESSION['verification_code'];

    // URL de la API de Telegram
    $url = "https://api.telegram.org/bot$bot_token/sendMessage";

    // Configurar los datos para la solicitud
    $data = [
        'chat_id' => $chat_id,
        'text' => $message
    ];

    // Enviar la solicitud a Telegram
    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    if ($result !== FALSE) {
        $message_sent = true;
    } else {
        $error_message = "Error al enviar el código. Intenta de nuevo.";
    }
}

// Si el formulario fue enviado con el código
if (isset($_POST['verify_code'])) {
    $user_code = $_POST['verification_code'];

    // Verificar si el código ingresado coincide
    if ($user_code == $_SESSION['verification_code']) {
        // Redirigir según el rol del usuario
        switch ($_SESSION['user_role']) {
            case 'admin':
                header('Location: admin/dashboard_admin.php');
                exit();
            case 'recepcionista':
                header('Location: recepcionista/dashboard_recep.php');
                exit();
            case 'tatuador':
                header('Location: tatuador/dashboard_tatuador.php');
                exit();
            default:
                $error_message = "Rol no reconocido.";
                break;
        }
    } else {
        $error_message = "El código ingresado es incorrecto.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Código</title>
    <link rel="stylesheet" href="css/loginCss.css">
</head>
<body>
    <div class="overlay"></div>
    <header>
        <img src="recursos/logo.jpg" alt="Logo Kraken">
    </header>
    <div class="form-container">
        <h2>Verificar Código</h2>

        <!-- Mostrar mensaje de éxito si el código fue enviado -->
        <?php if ($message_sent): ?>
            <div class="success-message">
                <p>El código fue enviado a tu Telegram.</p>
            </div>
        <?php endif; ?>

        <!-- Mostrar mensaje de error si existe -->
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <p><?php echo $error_message; ?></p>
            </div>
        <?php endif; ?>

        <!-- Botón para enviar el código -->
        <form action="verify_code.php" method="POST" style="margin-bottom: 20px;">
            <button type="submit" name="send_code">Enviar Código</button>
        </form>

        <!-- Formulario para ingresar el código -->
        <form action="verify_code.php" method="POST">
            <label for="verification_code">Código de Verificación</label>
            <input type="text" id="verification_code" name="verification_code" placeholder="Ingresa el código enviado a Telegram" required>
            <button type="submit" name="verify_code">Verificar</button>
        </form>
    </div>
    
    <footer>
        <p>¿Regresar al inicio? <a href="index.php">Haz clic aquí</a></p>
    </footer>
</body>
</html>
