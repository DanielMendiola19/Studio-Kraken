<?php
// Iniciar sesión para usar las variables de sesión
session_start();

// Incluir la conexión a la base de datos
include('connection.php');

// Variable para los mensajes de error
$error_message = "";

// Inicializar intentos y tiempo si no existen
if (!isset($_SESSION['intentos'])) {
    $_SESSION['intentos'] = 0;
    $_SESSION['ultimo_intento'] = time(); // Guardamos el tiempo del primer intento
}

// Verificar si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_usuario = $_POST['email_usuario'];
    $password_usuario = $_POST['password_usuario'];
    $rol_usuario = $_POST['rol_usuario']; // Recibir el rol

    // Verificar si el tiempo de bloqueo ha pasado
    if ($_SESSION['intentos'] >= 3 && (time() - $_SESSION['ultimo_intento']) < 60) {
        $error_message = "Has excedido el número de intentos. Intenta nuevamente en 1 minuto.";
    } else {
        // Reiniciar el contador de intentos después de 1 minuto
        if ((time() - $_SESSION['ultimo_intento']) > 60) {
            $_SESSION['intentos'] = 0;
        }

        // Consulta para obtener los datos del usuario
        $query = "SELECT * FROM usuarios WHERE email_usuario = ? LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $email_usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        // Verificar si el usuario existe
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if ($password_usuario == $user['password_usuario']) { // Comparar la contraseña
                if ($rol_usuario == $user['rol']) {
                    $_SESSION['intentos'] = 0;
                    $_SESSION['user_id'] = $user['id_usuario'];
                    $_SESSION['user_role'] = $rol_usuario;

                    // Redirigir a verify_code.php para la verificación
                    header('Location: verify_code.php');
                    exit();
                } else {
                    $error_message = "El rol seleccionado no coincide con el rol del usuario.";
                    $_SESSION['intentos']++;
                    $_SESSION['ultimo_intento'] = time();
                }
            } else {
                $error_message = "Contraseña incorrecta.";
                $_SESSION['intentos']++;
                $_SESSION['ultimo_intento'] = time();
            }
        } else {
            $error_message = "Usuario no encontrado.";
            $_SESSION['intentos']++;
            $_SESSION['ultimo_intento'] = time();
        }
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="css/loginCss.css">
</head>
<body>
    <div class="overlay"></div>
    <header>
        <img src="recursos/logo.jpg" alt="Logo Kraken">
    </header>
    <div class="form-container">
        <h2>Iniciar Sesión</h2>

        <!-- Mostrar mensaje de error si existe -->
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <p><?php echo $error_message; ?></p>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <label for="email_usuario">Email</label>
            <input type="email" id="email_usuario" name="email_usuario" placeholder="Ingresa tu email" required>
            
            <label for="password_usuario">Contraseña</label>
            <input type="password" id="password_usuario" name="password_usuario" placeholder="Ingresa tu contraseña" required>
            
            <label for="rol_usuario">Rol</label>
            <select id="rol_usuario" name="rol_usuario" required>
                <option value="recepcionista">Recepcionista</option>
                <option value="admin">Admin</option>
                <option value="tatuador">Tatuador</option>
            </select>
            
            <!-- Deshabilitar el formulario si está bloqueado -->
            <?php if ($_SESSION['intentos'] >= 3 && (time() - $_SESSION['ultimo_intento']) < 60): ?>
                <button type="submit" disabled>Formulario Bloqueado</button>
            <?php else: ?>
                <button type="submit">Iniciar Sesión</button>
            <?php endif; ?>
        </form>
    </div>
    
    <footer>
        <p>¿Regresar al inicio? <a href="index.php">Haz clic aquí</a></p>
    </footer>
</body>
</html>
