<?php
// Conexión a la base de datos
session_start();
include 'connection.php';

// Inicializar un mensaje de sesión para mostrar al usuario
if (!isset($_SESSION['mensaje'])) {
    $_SESSION['mensaje'] = '';
}

// Crear nuevo usuario
if (isset($_POST['create'])) {
    $nombre_usuario = $_POST['nombre_usuario'];
    $email_usuario = $_POST['email_usuario'];
    $password_usuario = password_hash($_POST['password_usuario'], PASSWORD_DEFAULT);  // Usamos hash para la contraseña
    $phone_usuario = $_POST['phone_usuario'];
    $rol = $_POST['rol'];

    $sql = "INSERT INTO usuarios (nombre_usuario, email_usuario, password_usuario, rol, phone_usuario)
            VALUES ('$nombre_usuario', '$email_usuario', '$password_usuario', '$rol', '$phone_usuario')";

    if ($conn->query($sql) === TRUE) {
        echo "Usuario creado exitosamente";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Editar usuario
if (isset($_POST['edit'])) {
    $id_usuario = $_POST['id_usuario'];
    $nombre_usuario = $_POST['nombre_usuario'];
    $email_usuario = $_POST['email_usuario'];
    $password_usuario = password_hash($_POST['password_usuario'], PASSWORD_DEFAULT);  // Usamos hash para la contraseña
    $phone_usuario = $_POST['phone_usuario'];
    $rol = $_POST['rol'];

    $sql = "UPDATE usuarios SET nombre_usuario = '$nombre_usuario', email_usuario = '$email_usuario', password_usuario = '$password_usuario', phone_usuario = '$phone_usuario', rol = '$rol' WHERE id_usuario = $id_usuario";

    if ($conn->query($sql) === TRUE) {
        echo "Usuario actualizado exitosamente";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Eliminar usuario
if (isset($_GET['delete'])) {
    $id_usuario = $_GET['delete'];
    $sql = "DELETE FROM usuarios WHERE id_usuario = $id_usuario";

    if ($conn->query($sql) === TRUE) {
        echo "Usuario eliminado exitosamente";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Obtener los usuarios
$sql = "SELECT * FROM usuarios";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD de Usuarios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #333;
            margin-top: 30px;
        }

        form, table {
            width: 80%;
            margin-top: 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
            margin-right: 10px;
        }

        input[type="text"], input[type="email"], input[type="password"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #007bff;
            color: white;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .actions a {
            color: #007bff;
            text-decoration: none;
            margin-right: 10px;
        }

        .actions a:hover {
            text-decoration: underline;
        }
        a {
    text-decoration: none;
    color: #007bff;
}
    </style>
</head>
<body>

<h1>CRUD de Usuarios</h1>
<a href="dashboard_admin.php" class="btn">Volver al Panel de Administración</a>

<!-- Formulario para crear un nuevo usuario -->
<h2>Crear Usuario</h2>
<form method="POST">
    <label for="nombre_usuario">Nombre:</label>
    <input type="text" name="nombre_usuario" id="nombre_usuario" required><br>

    <label for="email_usuario">Correo electrónico:</label>
    <input type="email" name="email_usuario" id="email_usuario" required><br>

    <label for="password_usuario">Contraseña:</label>
    <input type="password" name="password_usuario" id="password_usuario" required><br>

    <label for="phone_usuario">Teléfono:</label>
    <input type="text" name="phone_usuario" id="phone_usuario" required><br>

    <label for="rol">Rol:</label>
    <select name="rol" id="rol" required>
        <option value="admin">Admin</option>
        <option value="recepcionista">Recepcionista</option>
        <option value="tatuador">Tatuador</option>
    </select><br>

    <button type="submit" name="create">Crear Usuario</button>
</form>

<!-- Mostrar los usuarios -->
<h2>Usuarios</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Correo Electrónico</th>
        <th>Rol</th>
        <th>Teléfono</th>
        <th>Acciones</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id_usuario'] . "</td>";
            echo "<td>" . $row['nombre_usuario'] . "</td>";
            echo "<td>" . $row['email_usuario'] . "</td>";
            echo "<td>" . $row['rol'] . "</td>";
            echo "<td>" . $row['phone_usuario'] . "</td>";
            echo "<td class='actions'>
                    <a href='?edit=" . $row['id_usuario'] . "'>Editar</a> | 
                    <a href='?delete=" . $row['id_usuario'] . "'>Eliminar</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No hay usuarios registrados</td></tr>";
    }
    ?>
</table>

<?php
// Si se va a editar un usuario
if (isset($_GET['edit'])) {
    $id_usuario = $_GET['edit'];
    $sql = "SELECT * FROM usuarios WHERE id_usuario = $id_usuario";
    $result = $conn->query($sql);
    $usuario = $result->fetch_assoc();
?>

<h2>Editar Usuario</h2>

<form method="POST">
    <input type="hidden" name="id_usuario" value="<?php echo $usuario['id_usuario']; ?>">

    <label for="nombre_usuario">Nombre:</label>
    <input type="text" name="nombre_usuario" value="<?php echo $usuario['nombre_usuario']; ?>" required><br>

    <label for="email_usuario">Correo electrónico:</label>
    <input type="email" name="email_usuario" value="<?php echo $usuario['email_usuario']; ?>" required><br>

    <label for="password_usuario">Contraseña:</label>
    <input type="password" name="password_usuario" value="<?php echo $usuario['password_usuario']; ?>" required><br>

    <label for="phone_usuario">Teléfono:</label>
    <input type="text" name="phone_usuario" value="<?php echo $usuario['phone_usuario']; ?>" required><br>

    <label for="rol">Rol:</label>
    <select name="rol" required>
        <option value="admin" <?php echo ($usuario['rol'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
        <option value="recepcionista" <?php echo ($usuario['rol'] == 'recepcionista') ? 'selected' : ''; ?>>Recepcionista</option>
        <option value="tatuador" <?php echo ($usuario['rol'] == 'tatuador') ? 'selected' : ''; ?>>Tatuador</option>
    </select><br>

    <button type="submit" name="edit">Actualizar Usuario</button>
</form>

<?php
}
?>

</body>
</html>

<?php
// Cerrar conexión
$conn->close();
?>
