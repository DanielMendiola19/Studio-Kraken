<?php
include('connection.php');

// Verificar si el formulario fue enviado
if (isset($_POST['email_usuario']) && isset($_POST['password_usuario']) && isset($_POST['rol_usuario'])) {
    $email_usuario = $_POST['email_usuario'];
    $password_usuario = $_POST['password_usuario'];
    $rol_usuario = $_POST['rol_usuario']; // Recibir el rol

    // Consulta para obtener los datos del usuario
    $query = "SELECT * FROM usuarios WHERE email_usuario = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $email_usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    // Verificar si el usuario existe
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verificar la contraseña
        if ($password_usuario == $user['password_usuario']) { // Comparar la contraseña en texto claro
            // Verificar si el rol coincide
            if ($rol_usuario == $user['rol']) {
                // Redirigir según el rol del usuario
                switch ($rol_usuario) {
                    case 'admin':
                        header('Location: admin/dashboard_admin.php');
                        exit();
                    case 'recepcionista':
                        header('Location: recepcionista/dashboard_recep.php');
                        exit();
                    case 'tatuador':
                        header('Location: tatuador/dashboard_tatuador.php');
                        exit();
                    default:
                        echo "Rol no reconocido.";
                        break;
                }
            } else {
                echo "El rol seleccionado no coincide con el rol del usuario.";
            }
        } else {
            echo "Contraseña incorrecta.";
        }
    } else {
        echo "Usuario no encontrado.";
    }

    $stmt->close();
}

$conn->close();
?>
