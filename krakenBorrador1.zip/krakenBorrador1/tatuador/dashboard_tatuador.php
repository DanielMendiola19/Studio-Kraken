<?php

// Lógica para cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    // Redirige al index.php fuera de la carpeta de administración
    header('Location: ../index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Kraken</title>
    <link rel="stylesheet" href="css/adminStyles.css">
</head>
<body>
    <header>
        <div id="banner">
            <h1>Estudio de Tatuajes - Kraken</h1>
        </div>
    </header>
    <main>
        <div class="dashboard-intro">
            <h2>Bienvenido al Panel de Administración de tatuadores</h2>
        </div>
        <div class="dashboard-links">
            
            <div class="link-item">
                <a href="citas.php">
                    <h3>Citas</h3>
                    <p>Consulta y organiza las citas del estudio.</p>
                </a>
            </div>
            
            <div class="link-item">
                <a href="materiales.php">
                    <h3>Materiales</h3>
                    <p>Controla los materiales y suministros.</p>
                </a>
            </div>
            <div class="link-item">
                <a href="servicios.php">
                    <h3>Servicios</h3>
                    <p>Define y edita los servicios ofrecidos.</p>
                </a>
            </div>
           
            <!-- Enlace de Logout -->
            <div class="link-item">
                <a href="?logout=true">
                    <h3>Cerrar Sesión</h3>
                    <p>Salir del panel de administración.</p>
                </a>
            </div>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Estudio Kraken. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
